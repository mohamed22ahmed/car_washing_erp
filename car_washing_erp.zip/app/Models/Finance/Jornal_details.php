<?php

namespace App\Models\Finance;

use Illuminate\Database\Eloquent\Model;

class Jornal_details extends Model
{
    //
}
