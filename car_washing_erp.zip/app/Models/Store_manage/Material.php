<?php

namespace App\Models\Store_manage;

use Illuminate\Database\Eloquent\Model;

class Material extends Model
{
    protected $table='materials';
}
