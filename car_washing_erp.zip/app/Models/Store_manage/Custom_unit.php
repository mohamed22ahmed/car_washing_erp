<?php

namespace App\Models\Store_manage;

use Illuminate\Database\Eloquent\Model;

class Custom_unit extends Model
{
    //
}
