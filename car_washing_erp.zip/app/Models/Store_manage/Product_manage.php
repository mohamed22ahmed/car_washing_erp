<?php

namespace App\Models\Store_manage;

use Illuminate\Database\Eloquent\Model;

class Product_manage extends Model
{
    protected $table="products_manages";
}
