<?php

namespace App\Models\Store_manage;

use Illuminate\Database\Eloquent\Model;

class Stored_manage extends Model
{
    //
}
