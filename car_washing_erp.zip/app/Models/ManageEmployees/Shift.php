<?php

namespace App\Models\ManageEmployees;

use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    //
}
