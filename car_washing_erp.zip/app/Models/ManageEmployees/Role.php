<?php

namespace App\Models\ManageEmployees;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable=['name','name_ar'];
}
