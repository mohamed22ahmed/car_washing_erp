<?php

namespace App\Models\ManageEmployees;

use Illuminate\Database\Eloquent\Model;

class Machine_setting extends Model
{
    protected $fillable=['name','name_ar'];
}
