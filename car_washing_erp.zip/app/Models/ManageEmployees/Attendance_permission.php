<?php

namespace App\Models\ManageEmployees;

use Illuminate\Database\Eloquent\Model;

class Attendance_permission extends Model
{
    //
}
