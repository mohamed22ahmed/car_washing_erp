<?php

namespace App\Models\ManageEmployees;

use Illuminate\Database\Eloquent\Model;

class Attendance_log extends Model
{
    protected $table='attendance_logs';
}
