<?php

namespace App\Models\Washing_tickets;

use Illuminate\Database\Eloquent\Model;

class Car_washing extends Model
{
    //
}
