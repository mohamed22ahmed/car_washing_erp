<?php

namespace App\Models\Washing_tickets;

use Illuminate\Database\Eloquent\Model;

class Carpet_washing extends Model
{
    //
}
