<?php

namespace App\Models\Tickets_manage;

use Illuminate\Database\Eloquent\Model;

class Washing_machine extends Model
{
    //
}
