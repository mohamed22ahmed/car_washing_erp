<?php

namespace App\Models\Tickets_manage;

use Illuminate\Database\Eloquent\Model;

class Maintenance_manage extends Model
{
    //
}
