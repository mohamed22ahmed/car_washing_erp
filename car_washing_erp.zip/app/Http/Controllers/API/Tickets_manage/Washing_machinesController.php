<?php

namespace App\Http\Controllers\API\Tickets_manage;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Washing_machinesController extends Controller
{
    //
}
