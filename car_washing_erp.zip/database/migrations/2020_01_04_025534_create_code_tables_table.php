<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCodeTablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('code_tables', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->smallInteger('sys_code_type');
            $table->smallInteger('sys_code');
            $table->string('name');
            $table->string('name_ar');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.

     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('code_tables');
    }
}
